# PERCY AI (offline Android assistant)

Target: Redmi 9, Android 10, arm64. Nothing here has been compiled or run yet.

## Get the APK for free (phone browser is enough)
1. Create a free GitHub account, then a new repository (public is simplest).
2. Upload everything in this folder (including the hidden `.github` folder) to the repo.
3. Open the repo's **Actions** tab, pick **Build PERCY AI APK**, press **Run workflow**.
4. After 15-25 minutes open the finished run, download the **PERCY-AI-APK** artifact (a zip), unzip, install `app-release.apk`.
   (Allow "install unknown apps" for your browser or file manager.)
If the build fails, open the failed step, copy the red error text and send it to Claude.

## First run
1. Download `qwen2.5-0.5b-instruct-q4_k_m.gguf` (about 400 MB, Hugging Face, Qwen/Qwen2.5-0.5B-Instruct-GGUF) and keep it in phone storage.
2. Open PERCY, allow the microphone, go to **Model**, tap **Import model from storage**.
3. Settings: allow display over other apps, MIUI Autostart, battery unrestricted, then switch on "Hey Percy".

## Limits
- Wake word uses a tiny Vosk grammar for "hey percy"; accuracy varies, battery use rises.
- Pop-up orb does not appear over the lock screen. Reading notifications is not built.
- Calls open the dialer after your "yes"; you press the call button. Alarms and timers open the clock app for you to confirm.
- Waveform animates while PERCY speaks but is not tied to real audio levels.
- Male voice depends on voices installed on the phone (use "Try next offline voice").
- Expect roughly 3-8 tokens/second on the Redmi 9.
