package com.percy.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** Animated circular AI core. Bars animate while PERCY speaks (driven by speaking state, not real audio levels). */
class OrbView(ctx: Context) : View(ctx) {
    @Volatile var phase: Phase = Phase.IDLE
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var glow: Shader? = null
    private var core: Shader? = null
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f; val b = min(w, h) / 2f
        glow = RadialGradient(cx, cy, b, intArrayOf(0x8800E5FF.toInt(), 0x3300E676, 0x00000000),
            floatArrayOf(0.35f, 0.65f, 1f), Shader.TileMode.CLAMP)
        core = RadialGradient(cx, cy, b * 0.62f, intArrayOf(0xFF2979FF.toInt(), 0xFF0A1F44.toInt(), 0xFF02060F.toInt()),
            floatArrayOf(0f, 0.65f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val b = min(width, height) / 2f
        val ph = phase
        val cycles = when (ph) { Phase.IDLE -> 1f; Phase.LISTENING -> 3f; Phase.THINKING -> 4f; Phase.SPEAKING -> 2f }
        val amp = if (ph == Phase.IDLE) 0.03f else 0.07f
        val pulse = 1f + amp * sin(2.0 * PI * t * cycles).toFloat()

        p.shader = glow
        c.drawCircle(cx, cy, b, p)

        c.save()
        c.scale(pulse, pulse, cx, cy)
        p.shader = core
        c.drawCircle(cx, cy, b * 0.62f, p)
        p.shader = null

        ring.strokeWidth = b * 0.04f
        val r1 = b * 0.72f
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1)
        ring.color = 0xFF00E676.toInt()
        c.drawArc(rect, 360f * t, 100f, false, ring)
        val r2 = b * 0.82f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        ring.color = 0xFF2979FF.toInt()
        c.drawArc(rect, 180f - 540f * t, 80f, false, ring)
        c.restore()

        if (ph == Phase.SPEAKING) {
            p.color = 0xFF00E5FF.toInt()
            val bw = b * 0.07f
            for (i in 0 until 7) {
                val hgt = b * 0.5f * (0.2f + 0.8f * abs(sin(2.0 * PI * (t * 3f + i / 7f)).toFloat()))
                val x = cx + (i - 3) * bw * 1.7f
                rect.set(x - bw / 2, cy - hgt / 2, x + bw / 2, cy + hgt / 2)
                c.drawRoundRect(rect, bw / 2, bw / 2, p)
            }
        }
    }
}
