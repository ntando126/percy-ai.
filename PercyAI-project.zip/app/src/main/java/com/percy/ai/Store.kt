package com.percy.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private val sp get() = Percy.app.getSharedPreferences("percy", Context.MODE_PRIVATE)

    var wake: Boolean
        get() = sp.getBoolean("wake", false)
        set(v) { sp.edit().putBoolean("wake", v).apply() }
    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }
    var voice: String
        get() = sp.getString("voice", "") ?: ""
        set(v) { sp.edit().putString("voice", v).apply() }

    private fun readList(key: String): List<String> {
        val a = try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map { a.getString(it) }
    }
    private fun writeList(key: String, l: List<String>) {
        sp.edit().putString(key, JSONArray(l).toString()).apply()
    }

    fun facts(): List<String> = readList("facts")
    fun addFact(f: String) {
        val l = facts().toMutableList()
        val t = f.trim().take(200)
        if (t.isNotEmpty() && t !in l) l.add(t)
        writeList("facts", l.takeLast(50))
    }
    fun removeFact(i: Int) { val l = facts().toMutableList(); if (i in l.indices) { l.removeAt(i); writeList("facts", l) } }
    fun clearFacts() = writeList("facts", emptyList())

    fun loadChat(): List<Msg> {
        val a = try { JSONArray(sp.getString("chat", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map { val o = a.getJSONObject(it); Msg(o.getString("r"), o.getString("t")) }
    }
    fun saveChat(l: List<Msg>) {
        val a = JSONArray()
        l.takeLast(200).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        sp.edit().putString("chat", a.toString()).apply()
    }

    fun archives(): List<String> = readList("archives")
    fun archive(l: List<Msg>) {
        if (l.none { it.role == "user" }) return
        val text = l.joinToString("\n\n") { (if (it.role == "user") "You: " else "PERCY: ") + it.text }
        writeList("archives", (archives() + text).takeLast(30))
    }
    fun removeArchive(i: Int) { val l = archives().toMutableList(); if (i in l.indices) { l.removeAt(i); writeList("archives", l) } }
    fun clearArchives() = writeList("archives", emptyList())
}
