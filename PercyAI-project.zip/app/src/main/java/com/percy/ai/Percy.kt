package com.percy.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.Executors

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }
data class Msg(val role: String, val text: String)
data class Overlay(val text: String, val phase: Phase)

/** Central coordinator: chat state, speech in, brain, speech out. */
object Percy {
    lateinit var app: Context
    const val GREETING = "Good day, creator. Percy systems are online. How may I assist you?"

    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val phase = MutableStateFlow(Phase.IDLE)
    val status = MutableStateFlow("")
    val overlay = MutableStateFlow<Overlay?>(null)
    val voskReady = MutableStateFlow(false)
    val voskError = MutableStateFlow<String?>(null)
    val importProgress = MutableStateFlow<Int?>(null)
    val brainTick = MutableStateFlow(0)

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var overlayOn = false
    private val clearTask = Runnable { overlayOn = false; overlay.value = null }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val saved = Store.loadChat()
        messages.value = if (saved.isEmpty()) listOf(Msg("assistant", GREETING)) else saved
        Speaker.init()
        Ears.load()
    }

    private fun push(m: Msg) { synchronized(this) { messages.value = messages.value + m } }
    private fun setLast(t: String) {
        synchronized(this) {
            val l = messages.value
            if (l.isNotEmpty()) messages.value = l.dropLast(1) + l.last().copy(text = t)
        }
    }
    private fun setOverlay(text: String, p: Phase) { if (overlayOn) overlay.value = Overlay(text, p) }
    private fun scheduleClear() { main.removeCallbacks(clearTask); main.postDelayed(clearTask, 6000) }
    fun dismissOverlay() { main.post { main.removeCallbacks(clearTask); clearTask.run() } }

    fun clearChat() {
        synchronized(this) {
            Store.archive(messages.value)
            messages.value = listOf(Msg("assistant", GREETING))
            Store.saveChat(messages.value)
        }
    }

    fun setWake(on: Boolean) { Ears.setWake(on) }

    fun micOnce() {
        if (phase.value != Phase.IDLE) return
        phase.value = Phase.LISTENING
        Ears.command()
    }

    fun onWake() {
        main.removeCallbacks(clearTask)
        overlayOn = true
        phase.value = Phase.LISTENING
        overlay.value = Overlay("Listening…", Phase.LISTENING)
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 120) } catch (_: Throwable) { }
        main.postDelayed({ Ears.command() }, 200)
    }

    fun onHeard(text: String) {
        setOverlay(text, Phase.THINKING)
        submit(text, true)
    }

    fun heardNothing() {
        phase.value = Phase.IDLE
        setOverlay("I did not catch that.", Phase.IDLE)
        if (overlayOn) scheduleClear()
        Ears.resume()
    }

    fun submit(text: String, voice: Boolean) {
        val t = text.trim()
        if (t.isEmpty()) return
        val hist = messages.value
        push(Msg("user", t))
        phase.value = Phase.THINKING
        worker.execute {
            try {
                val direct = Actions.handle(app, t)
                if (direct != null) { finish(direct, voice, false); return@execute }
                if (!Brain.hasModel()) {
                    finish("My local brain is not installed yet. Open the Model tab and import the Qwen GGUF file.", voice, false)
                    return@execute
                }
                push(Msg("assistant", ""))
                val sb = StringBuilder()
                val err = Brain.reply(hist, t) { piece ->
                    sb.append(piece)
                    setLast(sb.toString().trim())
                    setOverlay(sb.toString().trim(), Phase.THINKING)
                }
                finish(err ?: sb.toString().trim().ifEmpty { "I have nothing to add, creator." }, voice, true)
            } catch (e: Throwable) {
                finish("Something went wrong: ${e.message}", voice, false)
            }
        }
    }

    private fun finish(reply: String, voice: Boolean, replace: Boolean) {
        if (replace) setLast(reply) else push(Msg("assistant", reply))
        Store.saveChat(messages.value)
        if (voice || Store.speak) {
            phase.value = Phase.SPEAKING
            setOverlay(reply, Phase.SPEAKING)
            main.post { Speaker.speak(reply) { done(reply) } }
        } else {
            done(reply)
        }
    }

    private fun done(reply: String) {
        phase.value = Phase.IDLE
        setOverlay(reply, Phase.IDLE)
        if (overlayOn) main.post { scheduleClear() }
        Ears.resume()
    }
}
