package com.percy.ai

interface TokenSink { fun onToken(bytes: ByteArray) }

object LlamaBridge {
    val available: Boolean = try { System.loadLibrary("percy_llama"); true } catch (t: Throwable) { false }
    external fun load(path: String, nCtx: Int, threads: Int): Boolean
    external fun generate(prompt: ByteArray, maxTokens: Int, sink: TokenSink): Int
    external fun stop()
    external fun unload()
}
