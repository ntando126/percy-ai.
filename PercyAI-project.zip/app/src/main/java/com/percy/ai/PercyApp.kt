package com.percy.ai

import android.app.Application

class PercyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Percy.init(this)
    }
}
