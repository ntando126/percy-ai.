package com.percy.ai

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/** Offline speech recognition (Vosk). Mode 1 = wake word only, mode 2 = full command. */
object Ears {
    private var model: Model? = null
    private var svc: SpeechService? = null
    private var rec: Recognizer? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile var wakeWanted = false
    @Volatile private var mode = 0
    @Volatile private var handled = false
    private const val GRAMMAR = "[\"hey percy\", \"hay percy\", \"[unk]\"]"

    fun load() {
        StorageService.unpack(Percy.app, "model-en", "model",
            { m: Model ->
                model = m
                Percy.voskReady.value = true
                if (wakeWanted) startWake()
            },
            { e: java.io.IOException -> Percy.voskError.value = "Speech model failed to load: ${e.message}" })
    }

    fun setWake(on: Boolean) { wakeWanted = on; if (on) startWake() else stop() }
    fun startWake() { main.post { if (wakeWanted) begin(1, GRAMMAR, 0) } }
    fun command() { main.post { begin(2, null, 9000) } }
    fun stop() { main.post { mode = 0; end() } }
    fun resume() {
        main.post {
            if (wakeWanted && Percy.phase.value == Phase.IDLE) begin(1, GRAMMAR, 0) else if (!wakeWanted) { mode = 0; end() }
        }
    }

    private fun end() {
        try { svc?.stop(); svc?.shutdown() } catch (_: Throwable) { }
        try { rec?.close() } catch (_: Throwable) { }
        svc = null; rec = null
    }

    private fun begin(m: Int, grammar: String?, timeout: Int) {
        end()
        val md = model
        if (md == null) {
            Percy.voskError.value = Percy.voskError.value ?: "Speech model is still loading."
            if (m == 2) Percy.heardNothing()
            return
        }
        try {
            mode = m; handled = false
            rec = if (grammar != null) Recognizer(md, 16000f, grammar) else Recognizer(md, 16000f)
            svc = SpeechService(rec, 16000f)
            if (timeout > 0) svc!!.startListening(listener, timeout) else svc!!.startListening(listener)
            Percy.voskError.value = null
        } catch (e: Throwable) {
            Percy.voskError.value = "Microphone error: ${e.message}"
            mode = 0; end()
            if (m == 2) Percy.heardNothing()
        }
    }

    private fun field(json: String?, key: String): String =
        try { JSONObject(json ?: "{}").optString(key, "") } catch (e: Exception) { "" }

    private fun checkWake(json: String?, key: String) {
        val t = field(json, key)
        if (!handled && (t.contains("hey percy") || t.contains("hay percy"))) {
            handled = true
            main.post { mode = 0; end(); Percy.onWake() }
        }
    }

    private fun heard(json: String?) {
        val t = field(json, "text").trim()
        if (t.isNotEmpty() && !handled) {
            handled = true
            main.post { mode = 0; end(); Percy.onHeard(t) }
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(h: String?) { if (mode == 1) checkWake(h, "partial") }
        override fun onResult(h: String?) { if (mode == 1) checkWake(h, "text") else if (mode == 2) heard(h) }
        override fun onFinalResult(h: String?) { if (mode == 2) heard(h) }
        override fun onError(e: Exception?) {
            main.post { Percy.voskError.value = "Listening error: ${e?.message}" }
        }
        override fun onTimeout() {
            if (mode == 2) main.post {
                if (!handled) { handled = true; mode = 0; end(); Percy.heardNothing() }
            }
        }
    }
}
