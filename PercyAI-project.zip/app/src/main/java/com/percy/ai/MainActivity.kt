package com.percy.ai

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

val Navy = Color(0xFF050B1A)
val CardBg = Color(0xFF0B1730)
val Blue = Color(0xFF2979FF)
val Green = Color(0xFF00E676)
val Amber = Color(0xFFFFB300)

fun hasMic(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
fun openIntent(c: Context, i: Intent): Boolean = try { c.startActivity(i); true } catch (e: Exception) { false }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.wake && hasMic(this)) Svc.start(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Green, background = Navy, surface = CardBg,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White)) { Root() }
        }
    }
}

@Composable
fun Orb(size: Dp, phase: Phase, onClick: (() -> Unit)? = null) {
    val m = if (onClick != null) Modifier.size(size).clickable { onClick() } else Modifier.size(size)
    AndroidView(factory = { OrbView(it) }, modifier = m, update = { it.phase = phase })
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun rememberMic(): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) Percy.micOnce() }
    return { if (hasMic(ctx)) Percy.micOnce() else launcher.launch(Manifest.permission.RECORD_AUDIO) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Root() {
    val tabs = listOf("Home", "Chat", "Voice", "History", "Memory", "Model", "Settings")
    var tab by remember { mutableIntStateOf(0) }
    val tick by Percy.brainTick.collectAsState()
    val brain = remember(tick) { Brain.statusText() }
    Column(Modifier.fillMaxSize().background(Navy)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PERCY AI", color = Green, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
            Text("● OFFLINE · $brain", color = if (brain.startsWith("Brain")) Green else Amber, fontSize = 11.sp)
        }
        ScrollableTabRow(selectedTabIndex = tab, containerColor = Navy, contentColor = Blue, edgePadding = 8.dp) {
            tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> HomeScreen { tab = it }
                1 -> ChatScreen()
                2 -> VoiceScreen()
                3 -> HistoryScreen()
                4 -> MemoryScreen()
                5 -> ModelScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun phaseText(p: Phase) = when (p) {
    Phase.IDLE -> "Standing by"
    Phase.LISTENING -> "Listening…"
    Phase.THINKING -> "Thinking…"
    Phase.SPEAKING -> "Speaking…"
}

@Composable
fun HomeScreen(go: (Int) -> Unit) {
    val phase by Percy.phase.collectAsState()
    val ready by Percy.voskReady.collectAsState()
    val vErr by Percy.voskError.collectAsState()
    val note by Percy.status.collectAsState()
    val tick by Percy.brainTick.collectAsState()
    val mic = rememberMic()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Orb(220.dp, phase) { mic() }
        Text(phaseText(phase), color = Color.White, fontSize = 16.sp)
        Text(Percy.GREETING, color = Color(0xFFB0C4FF), fontSize = 14.sp)
        Button(onClick = { mic() }) { Text("Speak to PERCY") }
        Panel {
            val b = remember(tick) { Brain.statusText() }
            Text("AI brain: $b", color = Color.White)
            Text("Speech recognition: " + (vErr ?: if (ready) "ready (offline)" else "loading…"), color = Color.White)
            Text("Hey Percy wake word: " + if (Store.wake) "on (see Settings)" else "off", color = Color.White)
            Text("Internet: this app has no internet permission", color = Color.White)
            if (note.isNotEmpty()) Text(note, color = Amber)
        }
        OutlinedButton(onClick = { go(1) }) { Text("Open chat") }
    }
}

@Composable
fun ChatScreen() {
    val msgs by Percy.messages.collectAsState()
    val phase by Percy.phase.collectAsState()
    var input by remember { mutableStateOf("") }
    val mic = rememberMic()
    val ls = rememberLazyListState()
    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text) { if (msgs.isNotEmpty()) ls.scrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(phaseText(phase), color = Color(0xFF8899BB), modifier = Modifier.weight(1f))
            TextButton(onClick = { Percy.clearChat() }) { Text("Clear conversation") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(msgs) { _, m ->
                val mine = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text.ifEmpty { "…" }, color = Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(if (mine) Blue else CardBg).padding(10.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type to PERCY") }, singleLine = true)
            OutlinedButton(onClick = { mic() }) { Text("Mic") }
            Button(onClick = { Percy.submit(input, false); input = "" }, enabled = phase == Phase.IDLE) { Text("Send") }
        }
    }
}

@Composable
fun VoiceScreen() {
    val phase by Percy.phase.collectAsState()
    val msgs by Percy.messages.collectAsState()
    val mic = rememberMic()
    val lastUser = msgs.lastOrNull { it.role == "user" }?.text ?: ""
    val lastBot = msgs.lastOrNull { it.role == "assistant" }?.text ?: ""
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Orb(260.dp, phase) { mic() }
        Text(phaseText(phase), color = Color.White, fontSize = 18.sp)
        if (lastUser.isNotEmpty()) Text("You: $lastUser", color = Color(0xFF8899BB))
        Text(lastBot, color = Color.White, fontSize = 16.sp)
        Button(onClick = { mic() }, enabled = phase == Phase.IDLE) { Text("Tap to speak") }
    }
}

@Composable
fun HistoryScreen() {
    var arch by remember { mutableStateOf(Store.archives()) }
    var open by remember { mutableIntStateOf(-1) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Past conversations (stored only on this phone)", color = Color(0xFF8899BB), modifier = Modifier.weight(1f))
            TextButton(onClick = { Store.clearArchives(); arch = emptyList() }) { Text("Delete all") }
        }
        if (arch.isEmpty()) Text("Nothing yet. Press “Clear conversation” in Chat to archive the current one.", color = Color.White)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(arch.reversed()) { ri, text ->
                val idx = arch.size - 1 - ri
                Panel {
                    Text(text.lineSequence().firstOrNull() ?: "", color = Green, modifier = Modifier.clickable { open = if (open == idx) -1 else idx })
                    if (open == idx) Text(text, color = Color.White)
                    TextButton(onClick = { Store.removeArchive(idx); arch = Store.archives(); open = -1 }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
fun MemoryScreen() {
    var facts by remember { mutableStateOf(Store.facts()) }
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("What PERCY remembers about you. Say “remember that …” or add it here.", color = Color(0xFF8899BB))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("e.g. I prefer short answers") })
            Button(onClick = { Store.addFact(input); input = ""; facts = Store.facts() }) { Text("Add") }
        }
        TextButton(onClick = { Store.clearFacts(); facts = emptyList() }) { Text("Delete everything stored") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(facts) { i, f ->
                Panel {
                    Text(f, color = Color.White)
                    TextButton(onClick = { Store.removeFact(i); facts = Store.facts() }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
fun ModelScreen() {
    val tick by Percy.brainTick.collectAsState()
    val prog by Percy.importProgress.collectAsState()
    val note by Percy.status.collectAsState()
    val ready by Percy.voskReady.collectAsState()
    val vErr by Percy.voskError.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) Brain.importModel(u) }
    val s = remember(tick) { Brain.statusText() }
    val size = remember(tick) { if (Brain.hasModel()) "${Brain.modelFile().length() / 1_000_000} MB" else "none" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel {
            Text("AI model", color = Green, fontWeight = FontWeight.Bold)
            Text("Status: $s", color = Color.White)
            Text("Installed model file: $size", color = Color.White)
            Text("Needed: Qwen2.5-0.5B-Instruct, Q4_K_M, .gguf file (about 400 MB). Copy it to your phone, then tap Import.", color = Color(0xFFB0C4FF))
            if (prog != null) Text("Importing… $prog%", color = Amber)
            if (note.isNotEmpty()) Text(note, color = Amber)
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = prog == null) { Text("Import model from storage") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { Brain.unloadNow() }) { Text("Unload from RAM") }
                OutlinedButton(onClick = { Brain.deleteModel() }) { Text("Delete model") }
            }
            Text("The model unloads itself after 3 minutes of inactivity. Context window: 1024 tokens.", color = Color(0xFF8899BB))
        }
        Panel {
            Text("Speech recognition", color = Green, fontWeight = FontWeight.Bold)
            Text(vErr ?: if (ready) "Offline Vosk English model: ready" else "Loading the speech model…", color = Color.White)
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var wake by remember { mutableStateOf(Store.wake) }
    var speak by remember { mutableStateOf(Store.speak) }
    var voice by remember { mutableStateOf(Speaker.currentName()) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { Store.wake = true; wake = true; Svc.start(ctx) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("“Hey Percy” wake word", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = wake, onCheckedChange = { on ->
                    if (on) {
                        if (hasMic(ctx)) { Store.wake = true; wake = true; Svc.start(ctx) } else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                    } else { Store.wake = false; wake = false; Svc.stop(ctx) }
                })
            }
            Text("Runs a small offline listener with a visible notification. Uses extra battery. If it misses you, use the Mic button instead.", color = Color(0xFF8899BB))
        }
        Panel {
            Text("Pop-up orb permission: " + if (Settings.canDrawOverlays(ctx)) "granted" else "not granted", color = Color.White)
            Button(onClick = {
                openIntent(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Allow display over other apps") }
            OutlinedButton(onClick = {
                val ok = openIntent(ctx, Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")))
                if (!ok) openIntent(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }) { Text("MIUI: allow Autostart") }
            OutlinedButton(onClick = { openIntent(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery: set PERCY to unrestricted") }
            Text("On Redmi/MIUI also enable “Display pop-up windows while running in the background” in the app's permissions page, and lock PERCY in the recent-apps screen.", color = Color(0xFF8899BB))
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speak typed replies aloud", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = speak, onCheckedChange = { Store.speak = it; speak = it })
            }
            Text("Voice: $voice", color = Color.White)
            OutlinedButton(onClick = { voice = Speaker.cycleVoice() }) { Text("Try next offline voice") }
            Text("Voices come from your phone's text-to-speech engine. Install offline English voices in Android's text-to-speech settings if few appear.", color = Color(0xFF8899BB))
        }
        Panel {
            Text("Not included in this version", color = Amber, fontWeight = FontWeight.Bold)
            Text("Reading notifications, live weather and internet search. The app has no internet permission by design.", color = Color.White)
        }
    }
}
