package com.percy.ai

import android.app.SearchManager
import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import android.content.Intent
import android.media.AudioManager
import android.view.KeyEvent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Phone actions. They run before the AI, and only report what Android actually accepted. */
object Actions {
    private var pendingCall: String? = null
    private val ones = listOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
        "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
    private val tens = mapOf("twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90)

    private fun go(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    private fun opened(ok: Boolean, what: String) =
        if (ok) "Opening $what now." else "Android would not let me open $what. Please check that PERCY has the display-over-other-apps permission."

    private fun numbers(s: String): List<Int> {
        val toks = s.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        val out = mutableListOf<Int>()
        var i = 0
        while (i < toks.size) {
            val w = toks[i]
            val d = w.toIntOrNull()
            when {
                d != null -> out.add(d)
                tens.containsKey(w) -> {
                    var v = tens[w]!!
                    val o = ones.indexOf(toks.getOrNull(i + 1) ?: "")
                    if (o in 1..9) { v += o; i++ }
                    out.add(v)
                }
                ones.indexOf(w) >= 0 -> out.add(ones.indexOf(w))
            }
            i++
        }
        return out
    }

    private fun mediaKey(ctx: Context, code: Int): Boolean = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        true
    } catch (e: Exception) { false }

    private fun volume(ctx: Context, dir: Int): Boolean = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI); true
    } catch (e: Exception) { false }

    private fun mediaReply(ok: Boolean, what: String) =
        if (ok) "Sent the $what command to your music player. Android does not tell me if the player obeyed."
        else "Android would not let me send the $what command."

    private fun findApp(ctx: Context, name: String): Intent? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val n = name.removePrefix("the ").removeSuffix(" app").trim()
        if (n.isEmpty()) return null
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
        return hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
    }

    fun handle(ctx: Context, raw: String): String? {
        val t = raw.lowercase().replace(Regex("[?!.,]"), "").trim()
        val words = t.split(" ").filter { it.isNotEmpty() }

        pendingCall?.let { num ->
            pendingCall = null
            return if (t in listOf("yes", "yes please", "confirm", "go ahead", "do it", "yeah", "yep", "ok", "okay")) {
                if (go(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))))
                    "I have put $num into the dialer. Press the green call button to place the call."
                else "Android would not open the dialer."
            } else "Call cancelled."
        }

        if (t.startsWith("remember ")) {
            val fact = raw.substring(raw.lowercase().indexOf("remember") + 8).trim().removePrefix("that ").trim()
            if (fact.isNotEmpty()) { Store.addFact(fact); return "Noted, creator. I will remember that." }
        }
        if (t.contains("what do you remember") || t.contains("what do you know about me")) {
            val f = Store.facts()
            return if (f.isEmpty()) "I have nothing stored about you yet." else "Here is what I have stored: " + f.joinToString(". ")
        }

        if (words.size > 14) return null

        if (Regex("\\b(weather|forecast|news|headlines)\\b").containsMatchIn(t) || t.contains("search the web") || t.contains("google"))
            return "Live weather, news and web searches need an internet connection. This offline version has none, and I will not guess."

        if (words.size <= 8 && Regex("\\b(what time|the time|current time)\\b").containsMatchIn(t))
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        if (words.size <= 8 && Regex("\\b(date|what day)\\b").containsMatchIn(t))
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + "."

        val playWords = listOf("play", "play music", "play the music", "resume", "resume music", "continue music", "unpause")
        if (t in playWords) return mediaReply(mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY), "play")
        if (t in listOf("pause", "pause music", "pause the music", "stop music", "stop the music", "stop playing"))
            return mediaReply(mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE), "pause")
        if (t in listOf("next", "next song", "next track", "skip", "skip song", "skip this song", "play next song"))
            return mediaReply(mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT), "next-song")
        if (t in listOf("previous", "previous song", "previous track", "last song", "go back a song", "play previous song"))
            return mediaReply(mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS), "previous-song")
        if (t in listOf("volume up", "louder", "turn it up", "turn the volume up"))
            return if (volume(ctx, AudioManager.ADJUST_RAISE)) "Raising the volume." else "Android would not change the volume."
        if (t in listOf("volume down", "quieter", "turn it down", "turn the volume down", "lower the volume"))
            return if (volume(ctx, AudioManager.ADJUST_LOWER)) "Lowering the volume." else "Android would not change the volume."
        if (t == "mute" || t == "mute the music")
            return if (volume(ctx, AudioManager.ADJUST_MUTE)) "Muting the music." else "Android would not mute the volume."
        if (t.startsWith("play ") && !t.contains("game")) {
            val q = t.removePrefix("play ").removePrefix("the song ").removePrefix("song ").trim()
            if (q.isNotEmpty()) {
                val i = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(SearchManager.QUERY, q).putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                return if (go(ctx, i)) "I asked your music app to play $q. If nothing starts, it did not find a match."
                else "No music app on this phone accepted that request."
            }
        }

        val settings = listOf(
            "wifi settings" to Settings.ACTION_WIFI_SETTINGS, "wi-fi settings" to Settings.ACTION_WIFI_SETTINGS,
            "bluetooth settings" to Settings.ACTION_BLUETOOTH_SETTINGS, "battery settings" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "display settings" to Settings.ACTION_DISPLAY_SETTINGS, "sound settings" to Settings.ACTION_SOUND_SETTINGS,
            "location settings" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
            "open settings" to Settings.ACTION_SETTINGS, "phone settings" to Settings.ACTION_SETTINGS, "open the settings" to Settings.ACTION_SETTINGS)
        settings.firstOrNull { t.contains(it.first) }?.let { return opened(go(ctx, Intent(it.second)), it.first) }

        if (t.contains("open camera") || t.contains("open the camera"))
            return opened(go(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)), "the camera")
        if (t.contains("calculator") && (t.contains("open") || t.contains("launch")))
            return opened(go(ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)), "the calculator")

        if (t.contains("timer")) {
            val n = numbers(t).firstOrNull() ?: return "For how long should the timer run?"
            val secs = when {
                t.contains("hour") -> n * 3600
                t.contains("second") -> n
                else -> n * 60
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "PERCY").putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            return if (go(ctx, i)) "I have opened your clock app with the timer. Please confirm it there." else "Android would not open the clock app."
        }
        if (t.contains("alarm") || t.startsWith("wake me") || t.startsWith("remind me")) {
            val nums = numbers(t)
            if (nums.isEmpty()) return "Tell me a time, for example: set an alarm for 7 30 pm. I will open the alarm screen for you to confirm."
            var h = nums[0]; val m = nums.getOrNull(1) ?: 0
            if ((t.contains(" pm") || t.contains("p m")) && h < 12) h += 12
            if ((t.contains(" am") || t.contains("a m")) && h == 12) h = 0
            if (h !in 0..23 || m !in 0..59) return "I could not understand that time."
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "PERCY").putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            return if (go(ctx, i)) "I have opened your clock app with an alarm for %d:%02d. Please confirm it there.".format(h, m) else "Android would not open the clock app."
        }

        if (t.startsWith("call ") || t.startsWith("phone ") || t.startsWith("dial ")) {
            val digits = t.substringAfter(" ").split(" ").mapNotNull {
                it.toIntOrNull()?.toString() ?: ones.indexOf(it).takeIf { i -> i in 0..9 }?.toString()
            }.joinToString("")
            if (digits.length < 3) return "I cannot look up contacts yet. Please give me the phone number."
            pendingCall = digits
            return "Shall I open the dialer for $digits? Say yes to confirm."
        }

        val mediaKey = when {
            t in listOf("play", "play music", "play the music", "resume", "resume music", "play some music") -> KeyEvent.KEYCODE_MEDIA_PLAY to "play"
            t in listOf("pause", "pause music", "pause the music", "stop music", "stop the music") -> KeyEvent.KEYCODE_MEDIA_PAUSE to "pause"
            t in listOf("next", "next song", "next track", "skip", "skip song") -> KeyEvent.KEYCODE_MEDIA_NEXT to "next"
            t in listOf("previous", "previous song", "previous track", "last song", "go back a song") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "previous"
            else -> null
        }
        if (mediaKey != null) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, mediaKey.first))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, mediaKey.first))
            return "I sent the ${mediaKey.second} button to your music app. Android does not tell me whether it worked, so if nothing happens, open the music app once first."
        }

        Regex("^(open|launch|start) (.+)$").find(t)?.let { m ->
            val name = m.groupValues[2]
            val i = findApp(ctx, name) ?: return "I could not find an app called $name."
            return opened(go(ctx, i), name)
        }
        return null
    }
}
