package com.percy.ai

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

/** Local AI brain: Qwen2.5-0.5B-Instruct GGUF through llama.cpp. Nothing leaves the phone. */
object Brain {
    private const val CTX = 1024
    private const val UNLOAD_MS = 180_000L
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var loaded = false

    private val unloadTask = Runnable {
        synchronized(this) {
            if (loaded) { LlamaBridge.unload(); loaded = false; Percy.brainTick.value++ }
        }
    }

    fun modelFile() = File(Percy.app.filesDir, "model.gguf")
    fun hasModel() = modelFile().exists() && modelFile().length() > 1_000_000

    fun statusText(): String = when {
        !LlamaBridge.available -> "AI engine failed to load"
        !hasModel() -> "No AI model imported yet"
        loaded -> "Brain loaded in memory"
        else -> "Brain installed (loads when needed)"
    }

    fun unloadNow() { synchronized(this) { if (loaded) { LlamaBridge.unload(); loaded = false } }; Percy.brainTick.value++ }
    fun deleteModel() { unloadNow(); modelFile().delete(); Percy.brainTick.value++ }

    private fun system(): String {
        val facts = Store.facts().joinToString("; ").take(500)
        return "You are PERCY, a calm, intelligent, professional personal assistant running fully offline on the user's phone. " +
            "The user is your creator; address them as creator now and then. Answer briefly, in one to three short sentences of plain speech, " +
            "with no markdown and no lists. You have no internet and no live data: for live weather, news or prices say you need an internet connection and never invent them. " +
            "You cannot control the phone yourself; the app does that separately. If you do not know something, say so." +
            (if (facts.isNotEmpty()) " Things you know about the user: $facts." else "")
    }

    private fun prompt(history: List<Msg>, user: String): String {
        var turns = history.filter { it.text.isNotBlank() }.takeLast(6)
        val u = user.take(800)
        fun build(): String {
            val sb = StringBuilder("<|im_start|>system\n${system()}<|im_end|>\n")
            turns.forEach { sb.append("<|im_start|>${it.role}\n${it.text.take(400)}<|im_end|>\n") }
            sb.append("<|im_start|>user\n$u<|im_end|>\n<|im_start|>assistant\n")
            return sb.toString()
        }
        while (build().length > 2400 && turns.isNotEmpty()) turns = turns.drop(1)
        return build()
    }

    /** Returns null on success, or an honest error message. */
    fun reply(history: List<Msg>, user: String, onPiece: (String) -> Unit): String? {
        if (!LlamaBridge.available) return "My local AI engine did not load, so I cannot think offline right now."
        synchronized(this) {
            main.removeCallbacks(unloadTask)
            if (!loaded) {
                Percy.status.value = "Loading brain into memory…"
                loaded = LlamaBridge.load(modelFile().absolutePath, CTX, 4)
                Percy.status.value = ""
                Percy.brainTick.value++
            }
            if (!loaded) return "I could not load the model. The file may be damaged, or the phone is low on memory."
            val rc = LlamaBridge.generate(prompt(history, user).toByteArray(Charsets.UTF_8), 200, object : TokenSink {
                override fun onToken(bytes: ByteArray) { onPiece(String(bytes, Charsets.UTF_8)) }
            })
            main.postDelayed(unloadTask, UNLOAD_MS)
            return when (rc) {
                0 -> null
                -2 -> "That was too long for my small memory window. Please shorten it."
                else -> "My AI engine reported an error (code $rc)."
            }
        }
    }

    fun importModel(uri: Uri) {
        Thread {
            try {
                val cr = Percy.app.contentResolver
                var size = -1L
                cr.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && c.moveToFirst()) size = c.getLong(i)
                }
                val dir = Percy.app.filesDir
                if (size > 0 && dir.usableSpace < size + 50_000_000L) {
                    Percy.status.value = "Not enough free storage for this model."; return@Thread
                }
                unloadNow()
                val tmp = File(dir, "model.part")
                Percy.importProgress.value = 0
                val input = cr.openInputStream(uri)
                if (input == null) { Percy.status.value = "Could not open that file."; Percy.importProgress.value = null; return@Thread }
                input.use { ins ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(1 shl 16)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (size > 0) {
                                val p = (done * 100 / size).toInt()
                                if (p != last) { last = p; Percy.importProgress.value = p }
                            }
                        }
                    }
                }
                val magic = ByteArray(4)
                tmp.inputStream().use { it.read(magic) }
                if (String(magic, Charsets.US_ASCII) != "GGUF") {
                    tmp.delete()
                    Percy.status.value = "That file is not a GGUF model."
                } else {
                    modelFile().delete()
                    tmp.renameTo(modelFile())
                    Percy.status.value = "Model imported successfully."
                }
            } catch (e: Throwable) {
                Percy.status.value = "Import failed: ${e.message}"
            } finally {
                Percy.importProgress.value = null
                Percy.brainTick.value++
            }
        }.start()
    }
}
