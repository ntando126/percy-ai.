package com.percy.ai

import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val main = Handler(Looper.getMainLooper())

    fun init() {
        tts = TextToSpeech(Percy.app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                applyVoice()
                tts?.setPitch(0.85f)
                tts?.setSpeechRate(0.95f)
                ready = true
            } else {
                Percy.status.value = "Text-to-speech engine unavailable on this phone"
            }
        }
    }

    private fun voices(): List<android.speech.tts.Voice> = try {
        tts?.voices?.filter { it.locale.language == "en" && !it.isNetworkConnectionRequired }?.sortedBy { it.name } ?: emptyList()
    } catch (e: Exception) { emptyList() }

    private fun maleHint(n: String): Boolean =
        (n.contains("male") && !n.contains("female")) || n.contains("iol") || n.contains("iom") || n.contains("tpd")

    private fun applyVoice() {
        val vs = voices()
        if (vs.isEmpty()) return
        val saved = Store.voice
        val pick = vs.firstOrNull { it.name == saved } ?: vs.firstOrNull { maleHint(it.name) } ?: vs.first()
        try { tts?.voice = pick } catch (e: Exception) { }
    }

    fun currentName(): String = try { tts?.voice?.name ?: "default" } catch (e: Exception) { "default" }

    fun cycleVoice(): String {
        val vs = voices()
        if (vs.isEmpty()) return "no offline English voices installed"
        val cur = currentName()
        val next = vs[(vs.indexOfFirst { it.name == cur } + 1).mod(vs.size)]
        Store.voice = next.name
        try { tts?.voice = next } catch (e: Exception) { }
        speak("This is my new voice, creator.") { }
        return next.name
    }

    fun speak(text: String, cb: () -> Unit) {
        val t = tts
        if (!ready || t == null) { main.post { cb() }; return }
        val clean = text.replace(Regex("[*#_`>]"), "").take(1500)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { cb() } }
            @Deprecated("required by base class")
            override fun onError(id: String?) { main.post { cb() } }
        })
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "percy")
    }
}
