package com.percy.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

object Svc {
    fun start(c: Context) { ContextCompat.startForegroundService(c, Intent(c, PercyService::class.java)) }
    fun stop(c: Context) { c.stopService(Intent(c, PercyService::class.java)) }
}

/** Foreground service: keeps the offline "Hey Percy" listener alive and shows the floating orb. */
class PercyService : Service() {
    private var orb: OrbOverlay? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("percy", "PERCY listening", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification_(pi)
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        Percy.setWake(true)
        scope.launch { Percy.overlay.collect { render(it) } }
    }

    @Suppress("FunctionName")
    private fun Notification_(pi: PendingIntent) = android.app.Notification.Builder(this, "percy")
        .setContentTitle("PERCY AI")
        .setContentText("Listening offline for “Hey Percy”")
        .setSmallIcon(R.drawable.ic_percy)
        .setContentIntent(pi)
        .build()

    private fun render(o: Overlay?) {
        if (o == null) { orb?.hide(); orb = null; return }
        if (!Settings.canDrawOverlays(this)) return
        if (orb == null) orb = OrbOverlay(this).also { it.show() }
        orb?.update(o.text, o.phase)
    }

    override fun onDestroy() {
        scope.cancel()
        orb?.hide()
        Percy.setWake(false)
        super.onDestroy()
    }
}

class OrbOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val orb = OrbView(ctx)
    private val label = TextView(ctx)
    private val close = TextView(ctx)
    private val root = LinearLayout(ctx)
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT)
    private var added = false

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    init {
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(orb, LinearLayout.LayoutParams(dp(88), dp(88)))
        label.setTextColor(0xFFFFFFFF.toInt()); label.textSize = 14f
        label.maxWidth = dp(240); label.setPadding(dp(12), dp(8), dp(12), dp(8)); label.visibility = View.GONE
        label.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xE60A1F44.toInt()); setStroke(dp(1), 0xFF2979FF.toInt()) }
        root.addView(label)
        close.text = "✕ dismiss"; close.setTextColor(0xFF8899BB.toInt()); close.textSize = 11f; close.setPadding(dp(8), dp(6), dp(8), dp(6))
        close.setOnClickListener { Percy.dismissOverlay() }
        root.addView(close)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16); lp.y = dp(140)
        orb.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = ox + dx; lp.y = oy + dy
                        if (added) wm.updateViewLayout(root, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
                return true
            }
        })
    }

    fun show() { try { wm.addView(root, lp); added = true } catch (_: Throwable) { } }
    fun hide() { try { if (added) wm.removeView(root) } catch (_: Throwable) { }; added = false }
    fun update(text: String, phase: Phase) {
        orb.phase = phase
        label.text = text
        label.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }
}
