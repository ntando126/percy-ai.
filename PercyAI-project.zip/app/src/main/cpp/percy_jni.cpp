#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <string>
#include <vector>
#include <algorithm>
#include "llama.h"

#define TAG "PercyLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static int g_nctx = 1024;
static int g_threads = 4;
static bool g_backend = false;
static std::atomic<bool> g_stop{false};

// length of the prefix of s that ends on a complete UTF-8 character
static size_t complete_utf8_len(const std::string& s) {
    size_t n = s.size();
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        i--; back++;
        unsigned char c = (unsigned char)s[i];
        if ((c & 0xC0) != 0x80) {
            int need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
            return back >= need ? n : i;
        }
    }
    return n;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_percy_ai_LlamaBridge_load(JNIEnv* env, jobject, jstring jpath, jint nctx, jint threads) {
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    if (!g_backend) { llama_backend_init(); g_backend = true; }
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    g_nctx = nctx;
    g_threads = threads;
    if (!g_model) LOGE("model load failed");
    return g_model != nullptr;
}

extern "C" JNIEXPORT void JNICALL
Java_com_percy_ai_LlamaBridge_unload(JNIEnv*, jobject) {
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

extern "C" JNIEXPORT void JNICALL
Java_com_percy_ai_LlamaBridge_stop(JNIEnv*, jobject) { g_stop = true; }

// returns 0 ok, -1 no model, -2 prompt too long, -3 context failed, -4 decode failed
extern "C" JNIEXPORT jint JNICALL
Java_com_percy_ai_LlamaBridge_generate(JNIEnv* env, jobject, jbyteArray jprompt, jint maxTokens, jobject sink) {
    if (!g_model) return -1;
    g_stop = false;
    jsize plen = env->GetArrayLength(jprompt);
    std::string prompt((size_t)plen, '\0');
    env->GetByteArrayRegion(jprompt, 0, plen, reinterpret_cast<jbyte*>(&prompt[0]));

    jclass sc = env->GetObjectClass(sink);
    jmethodID mid = env->GetMethodID(sc, "onToken", "([B)V");
    if (!mid) return -4;

    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    int n = -llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), nullptr, 0, false, true);
    if (n <= 0) return -4;
    std::vector<llama_token> toks((size_t)n);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), toks.data(), (int32_t)toks.size(), false, true) < 0) return -4;
    if (n + 16 >= g_nctx) return -2;
    int budget = std::min((int)maxTokens, g_nctx - n - 1);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = g_nctx;
    cp.n_batch = 512;
    cp.n_threads = g_threads;
    cp.n_threads_batch = g_threads;
    llama_context* ctx = llama_init_from_model(g_model, cp);
    if (!ctx) return -3;

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int rc = 0;
    for (int i = 0; i < n && rc == 0; i += 512) {
        int c = std::min(512, n - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, c);
        if (llama_decode(ctx, b) != 0) rc = -4;
    }

    std::string pending;
    auto flush = [&](bool all) {
        size_t k = all ? pending.size() : complete_utf8_len(pending);
        if (k == 0) return;
        jbyteArray arr = env->NewByteArray((jsize)k);
        env->SetByteArrayRegion(arr, 0, (jsize)k, reinterpret_cast<const jbyte*>(pending.data()));
        env->CallVoidMethod(sink, mid, arr);
        env->DeleteLocalRef(arr);
        pending.erase(0, k);
    };

    for (int i = 0; i < budget && rc == 0 && !g_stop; i++) {
        llama_token tok = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (len > 0) pending.append(buf, (size_t)len);
        flush(false);
        if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(ctx, b) != 0) { rc = -4; break; }
    }
    flush(false);

    llama_sampler_free(smpl);
    llama_free(ctx);
    return rc;
}
